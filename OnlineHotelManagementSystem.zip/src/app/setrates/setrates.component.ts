import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setrates',
  templateUrl: './setrates.component.html',
  styleUrls: ['./setrates.component.css']
})
export class SetratesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
