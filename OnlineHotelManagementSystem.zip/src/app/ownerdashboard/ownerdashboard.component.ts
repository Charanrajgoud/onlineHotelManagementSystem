import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { HotelMangementServicesService } from '../services/hotel-mangement-services.service';

@Component({
  selector: 'app-ownerdashboard',
  templateUrl: './ownerdashboard.component.html',
  styleUrls: ['./ownerdashboard.component.css']
})
export class OwnerdashboardComponent implements OnInit {

  showError = false;
  errorUserAdding = false;
  errorUserUpdating = false;

  userId: any;
  name: any;
  mobileNumber: any;
  email: any;
  gender: any;
  salary: any;
  nic: any;
  address: any;
  password: any;
  role: any;
  routeParameter: any;
  addManagerSubscription: Subscription = new Subscription;
  updateManagerSubscription: Subscription = new Subscription;
  selectedRole = 'owner';
  userRoles = ['owner', 'manager'];
  loggedInUserRole:any;

  constructor(public manageUser: HotelMangementServicesService, private activeRoute: ActivatedRoute, public router: Router) { }

  ngOnInit(): void {
    this.loggedInUserRole = localStorage.getItem('loginUserRole');
    if (this.loggedInUserRole == 'manager') {
      this.userRoles = ['staff'];
      this.selectedRole = 'staff';
    }
    this.activeRoute.params.subscribe(routeParams => {
      this.routeParameter = routeParams['id'];
    });
    if (this.routeParameter == 'updateUser') {
      const userData: any = localStorage.getItem('ToUpdateUserData');
      const user = JSON.parse(userData);
      this.userId = user.userId;
      this.name = user.name;
      this.mobileNumber = user.mobileNumber;
      this.email = user.email;
      this.gender = user.gender;
      this.salary = user.salary;
      this.nic = user.nic;
      this.address = user.address;
      this.password = user.password;
      this.role = user.role;
      this.selectedRole = user.role;
    }
  }

  onUserFormSubmit(UserDetails: any) {
    this.errorUserAdding = false;
    this.errorUserUpdating = false;
    const emailPattern = /^[a-z0-9]+@[a-z]+\.[a-z]{2,3}/;
    let isValid = true;
    if(UserDetails.valid){
      this.showError = false;
    }else{
      isValid = false;
      this.showError = true;
    }

    if(emailPattern.test(this.email)){
      document.getElementById('userEmail')?.classList.remove('redBorder');
    }else{
      isValid = false;
      document.getElementById('userEmail')?.classList.add('redBorder');
    }

    if(isValid) {
      console.log("details", UserDetails.value);
      if (this.routeParameter == 'addUser') {
        this.addManagerSubscription = this.manageUser.AddUser(UserDetails.value).subscribe((data) => {
          console.log("response", data);
          this.router.navigate(['/Dashboard/'+this.loggedInUserRole]);
        },error =>{
          this.errorUserAdding = true;
        });
      } else {
        this.updateManagerSubscription = this.manageUser.updateUser(this.userId, UserDetails.value).subscribe((data) => {
          console.log("response", data);
            this.router.navigate(['/Dashboard/'+this.loggedInUserRole]);
        },error =>{
          this.errorUserUpdating = true;
        });
      }
    }

  }


}
