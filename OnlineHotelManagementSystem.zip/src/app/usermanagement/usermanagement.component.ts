import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { HotelMangementServicesService } from '../services/hotel-mangement-services.service';

@Component({
  selector: 'app-usermanagement',
  templateUrl: './usermanagement.component.html',
  styleUrls: ['./usermanagement.component.css']
})
export class UsermanagementComponent implements OnInit {
  
  getManagerSubscription: Subscription = new Subscription;
  deleteManagerSubscription: Subscription = new Subscription;
  users:any;
  routeParameter:any;
  serachByName:any;

  constructor(public manageUser: HotelMangementServicesService, public router:Router, private activeRoute: ActivatedRoute,) { }

  ngOnInit(): void {
    this.getUsers();
    this.activeRoute.params.subscribe(routeParams => {
      this.routeParameter = routeParams['id'];
    });
  }

  navigateToAddUser() {
    this.router.navigate(['/Dashboard/addUser'])
  }
  updateUser(userData:any) {
    localStorage.removeItem('ToUpdateUserData');
    localStorage.setItem('ToUpdateUserData', JSON.stringify(userData));
    this.router.navigate(['/Dashboard/updateUser']);
  }
  getUsers(){
    this.getManagerSubscription = this.manageUser.getUsers().subscribe((data) => {
      const userData:any = data;
      if(this.routeParameter == 'owner'){
        this.users = userData.filter((item: { role: string; }) => item.role == 'owner' || item.role == 'manager');
      }else {
        this.users = userData.filter((item: { role: string; }) => item.role == 'staff');
      }
        
    });
  }
  deleteUser(userId:any){
    this.deleteManagerSubscription = this.manageUser.deleteUser(userId).subscribe((data) => {
      console.log("response", data);
      this.getUsers();
    });

  }
}
