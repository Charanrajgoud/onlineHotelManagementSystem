import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageguest',
  templateUrl: './manageguest.component.html',
  styleUrls: ['./manageguest.component.css']
})
export class ManageguestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
