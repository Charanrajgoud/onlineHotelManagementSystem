import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { HotelMangementServicesService } from '../services/hotel-mangement-services.service';

@Component({
  selector: 'app-receptionist',
  templateUrl: './receptionist.component.html',
  styleUrls: ['./receptionist.component.css']
})
export class ReceptionistComponent implements OnInit {
  membercode: any;
  name: any;
  age: any;
  mobileNumber: any;
  gender: any;
  email: any;
  city: any;
  pincode: any;
  citizenship: any;
  occupation: any;
  drivingLicence: any;
  routeParameter: any;
  ReceptionistUser: any;
  addGuestSubscription: Subscription = new Subscription;
  errorGuestAdding = false;
  showError = false;
  // updateReceptionistSubscription: Subscription = new Subscription;
  constructor(public manageGuest: HotelMangementServicesService, private activeRoute: ActivatedRoute, public router: Router) { }

  ngOnInit(): void {
    this.activeRoute.params.subscribe(routeParams => {
      this.routeParameter = routeParams['id'];
    });
  }
  onReceptionistFormSubmit(ReceptionistDetails: any) {
    console.log("details", ReceptionistDetails.value);
    this.errorGuestAdding = false;
    const emailPattern = /^[a-z0-9]+@[a-z]+\.[a-z]{2,3}/;
    let isValid = true;
    if (ReceptionistDetails.valid) {
      this.showError = false;
    } else {
      isValid = false;
      this.showError = true;
    }

    if (emailPattern.test(this.email)) {
      document.getElementById('guestEmail')?.classList.remove('redBorder');
    } else {
      isValid = false;
      document.getElementById('guestEmail')?.classList.add('redBorder');
    }
    if (isValid) {
      this.addGuestSubscription = this.manageGuest.AddGuest(ReceptionistDetails.value).subscribe((data: any) => {
        console.log("response", data);

      });
    }

  }

}