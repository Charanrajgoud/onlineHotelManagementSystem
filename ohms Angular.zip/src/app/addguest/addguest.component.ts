import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-addguest',
  templateUrl: './addguest.component.html',
  styleUrls: ['./addguest.component.css']
})
export class AddguestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
