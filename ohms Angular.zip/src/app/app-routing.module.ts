import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ManageguestComponent } from './manageguest/manageguest.component';
import { ReceptionistComponent } from './receptionist/receptionist.component';
import { SignupComponent } from './signup/signup.component';
import { AddguestComponent } from './addguest/addguest.component';
import { OwnerdashboardComponent } from './ownerdashboard/ownerdashboard.component';
import { ManagerdashboardComponent } from './managerdashboard/managerdashboard.component';
import { DashboardsComponent } from './dashboards/dashboards.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [ 
  { path: 'Login', component: LoginComponent},
  { path: 'Signup', component: SignupComponent},
  { path: 'Receptionist', component: ReceptionistComponent},
  { path: 'Managegust', component: ManageguestComponent},
  { path: 'Addguest', component: AddguestComponent},
  { path: 'OwnerDashboard', component: OwnerdashboardComponent},
  { path: 'ManagerDashboard', component: ManagerdashboardComponent},
  { path: 'Dashboard/:id', component: DashboardsComponent},
  { path: '', component: HomeComponent},
  { path: 'Home', component: HomeComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
