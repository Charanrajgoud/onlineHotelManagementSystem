import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { HotelMangementServicesService } from '../services/hotel-mangement-services.service';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {

  
  inventoryName: any;
  quantity: any;
  unitPrice: any;
  
  successfullySubmited = false;


  
  
  routeParameter: any;
  ReceptionistUser: any;
  addInventorySubscription: Subscription = new Subscription;
  errorinventoryAdding = false;
  showError = false;

  constructor(public manageInventory: HotelMangementServicesService, private activeRoute: ActivatedRoute, public router: Router) { }

  ngOnInit(): void {
    this.activeRoute.params.subscribe(routeParams => {
      this.routeParameter = routeParams['id'];
    });
  }


  onInventoryFormSubmit(inventoryDetails: any) {
    console.log("details", inventoryDetails.value);
    this.errorinventoryAdding = false;
    this.successfullySubmited = false;
   
    let isValid = true;
    if (inventoryDetails.valid) {
      this.showError = false;
    } else {
      isValid = false;
      this.showError = true;
    }

    
    if (isValid) {
      this.addInventorySubscription = this.manageInventory.AddInventory(inventoryDetails.value).subscribe((data: any) => {
        console.log("response", data);
        this.successfullySubmited = true;
        inventoryDetails.reset();
      },error =>{
        this.errorinventoryAdding = true;
      });
    }

  }
}
