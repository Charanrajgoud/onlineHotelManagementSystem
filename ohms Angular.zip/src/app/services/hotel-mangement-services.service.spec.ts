import { TestBed } from '@angular/core/testing';

import { HotelMangementServicesService } from './hotel-mangement-services.service';

describe('HotelMangementServicesService', () => {
  let service: HotelMangementServicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HotelMangementServicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
