﻿using System.Linq;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementSystem;

        public LoginController(OnlineHotelManagementSystemContext onlineHotelManagementSystem)
        {
            _onlineHotelManagementSystem = onlineHotelManagementSystem;
        }
        [HttpPost]
        public IActionResult Login([FromBody] LoginData loginObj)
        {
            if (loginObj == null)
            {
                return BadRequest();
            }
            else
            {
                var user = _onlineHotelManagementSystem.Staff.Where(a => a.Role == loginObj.Role &&
                a.Email == loginObj.Email
                && a.Password == loginObj.Password).FirstOrDefault();
                if (user != null)
                {
                    return Ok(new
                    {
                        StatusCode = 200,
                        Message = "Logged in Sucessfully",
                        UserData = loginObj.Email
                    });
                }
                else
                {
                    return NotFound(new
                    {
                        StatusCode = 404,
                        Message = "User Not Found"
                    });
                }
            }
        }
    }
}
