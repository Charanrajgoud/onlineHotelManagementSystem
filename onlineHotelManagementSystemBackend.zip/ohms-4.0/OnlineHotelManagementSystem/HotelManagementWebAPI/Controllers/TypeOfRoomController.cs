﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TypeOfRoomController : ControllerBase
    {
        private readonly ITypeOfRoomData<TypeOfRoom> _roomRepository;

        public TypeOfRoomController(ITypeOfRoomData<TypeOfRoom> roomRepository)
        {
            _roomRepository = roomRepository;
        }
        [HttpGet]
        public async Task<IEnumerable<TypeOfRoom>> GetTypeOfRooms()
        {
            return await _roomRepository.Get();

        }
        [HttpPost]
        public async Task<TypeOfRoom> PostRoom([FromBody] TypeOfRoomData roomData)
        {
            var newroom = await _roomRepository.AddRoom(roomData);
            return newroom;
        }
    }
}
