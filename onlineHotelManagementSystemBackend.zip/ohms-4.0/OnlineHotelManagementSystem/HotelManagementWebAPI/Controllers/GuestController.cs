﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GuestController : ControllerBase
    {
        private readonly IGuestData<Guest> _guestRepository;

        public GuestController(IGuestData<Guest> guestRepository)
        {
            _guestRepository = guestRepository;
        }
        [HttpGet]
        public async Task<IEnumerable<Guest>> GetGuests()
        {
            return await _guestRepository.Get();

        }
        [HttpGet("{MemberCode}")]
        public async Task<ActionResult<Guest>> GetGuests(int MemberCode)
        {
            return await _guestRepository.Get(MemberCode);

        }
        [HttpPost]
        public async Task<Guest> PostGuest([FromBody] GuestData guestData)
        {
            var newguest = await _guestRepository.AddUser(guestData);
            return newguest;
        }
        [HttpDelete("{MemberCode}")]
        public async Task<ActionResult> Delete(int MemberCode)
        {
            var guestToDelete = await _guestRepository.Get(MemberCode);
            if (guestToDelete == null)
            {
                return NotFound();

            }
            await _guestRepository.Delete(guestToDelete.MemberCode);
            return NoContent();
        }
    }
}
