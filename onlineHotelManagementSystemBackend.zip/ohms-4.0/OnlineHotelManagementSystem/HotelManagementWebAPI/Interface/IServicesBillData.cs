﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Interface
{
    public interface IServicesBillData<T>
    {
        Task<ServicesBill> Get(int BillNo);
        Task<ServicesBill> AddBill(ServicesBillData servicesBillData);
    }
}
