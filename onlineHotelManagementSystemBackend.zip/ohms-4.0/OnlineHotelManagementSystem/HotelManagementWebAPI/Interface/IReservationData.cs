﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Interface
{
    public interface IReservationData<T>
    {
        Task<MakeReservation> AddUser(ReservationData reservationData);
    }
}
