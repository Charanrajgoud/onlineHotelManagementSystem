﻿using System;
using System.Collections.Generic;

namespace HotelManagementWebAPI.Models
{
    public partial class Invoice
    {
        public Invoice()
        {
            PaymentDetails = new HashSet<PaymentDetails>();
        }

        public int InvoiceId { get; set; }
        public int? MemberCode { get; set; }
        public int RoomPrice { get; set; }
        public int ServicesCost { get; set; }
        public int Total { get; set; }

        public virtual Guest MemberCodeNavigation { get; set; }
        public virtual ICollection<PaymentDetails> PaymentDetails { get; set; }
    }
}
