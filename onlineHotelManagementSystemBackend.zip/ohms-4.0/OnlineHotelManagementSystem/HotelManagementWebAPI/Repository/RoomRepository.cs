﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Repository
{
    public class RoomRepository : IRoomData<Room>
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementContext;

        public RoomRepository(OnlineHotelManagementSystemContext onlineHotelManagementContext)
        {
            _onlineHotelManagementContext = onlineHotelManagementContext;
        }
        public async Task<Room> AddRoom(RoomData roomData)
        {
            var newRoom = new Room()
            {
                RoomId = roomData.RoomId,
                RoomName = roomData.RoomName,
                BuildingNumber = roomData.BuildingNumber,
                FloorNumber = roomData.FloorNumber,
                Status = roomData.Status,

            };
            if (newRoom == null)
            {
                return null;
            }
            await _onlineHotelManagementContext.Room.AddAsync(newRoom);
            await _onlineHotelManagementContext.SaveChangesAsync();
            return newRoom;
        }

        public async Task<Room> Get(int roomId)
        {
            return await _onlineHotelManagementContext.Room.FindAsync(roomId);
        }
    }
}
