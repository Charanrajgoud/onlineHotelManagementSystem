﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Repository
{
    public class ReservationRepository : IReservationData<MakeReservation>
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementContext;

        public ReservationRepository(OnlineHotelManagementSystemContext onlineHotelManagementContext)
        {
            _onlineHotelManagementContext = onlineHotelManagementContext;
        }
        public async Task<MakeReservation> AddUser(ReservationData reservationData)
        {
            var reservation = new MakeReservation()
            {
                ReservationCode = reservationData.ReservationCode,
                RoomId = reservationData.RoomId,
                MemberCode = reservationData.MemberCode,
                CheckInTime = reservationData.CheckInTime,
                CheckOutTime = reservationData.CheckOutTime,
                NoOfNights = reservationData.NoOfNights,
                RoomPrice = reservationData.RoomPrice,

            };
            if (reservation == null)
            {
                return null;
            }
            await _onlineHotelManagementContext.MakeReservation.AddAsync(reservation);
            await _onlineHotelManagementContext.SaveChangesAsync();
            return reservation;
        }
    }
}
