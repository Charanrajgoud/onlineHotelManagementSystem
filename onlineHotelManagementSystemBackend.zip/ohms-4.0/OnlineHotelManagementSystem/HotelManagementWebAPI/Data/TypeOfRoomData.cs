﻿namespace HotelManagementWebAPI.Data
{
    public class TypeOfRoomData
    {
        public string RoomType { get; set; }
        public int Adults { get; set; }
        public int Child { get; set; }
        public int StandardPrice { get; set; }
    }
}
