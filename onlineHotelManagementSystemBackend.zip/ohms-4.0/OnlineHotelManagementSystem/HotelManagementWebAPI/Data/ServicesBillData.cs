﻿using System;

namespace HotelManagementWebAPI.Data
{
    public class ServicesBillData
    {
        public int BillNo { get; set; }
        public DateTime Date { get; set; }
        public int Price { get; set; }
        public int Tax { get; set; }
        public int Units { get; set; }
        public string ItemName { get; set; }
        public int? MemberCode { get; set; }
        public int? ReservationCode { get; set; }
        public int Amount { get; set; }
    }
}
