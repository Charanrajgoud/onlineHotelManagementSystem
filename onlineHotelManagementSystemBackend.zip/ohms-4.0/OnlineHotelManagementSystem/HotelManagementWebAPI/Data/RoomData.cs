﻿namespace HotelManagementWebAPI.Data
{
    public class RoomData
    {
        public int RoomId { get; set; }
        public string RoomName { get; set; }
        public int BuildingNumber { get; set; }
        public int FloorNumber { get; set; }
        public string Status { get; set; }
        public string RoomType { get; set; }
    }
}
